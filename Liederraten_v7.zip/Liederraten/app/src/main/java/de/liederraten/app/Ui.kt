package de.liederraten.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF04210F),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE8EDF2),
    surface = Color(0xFF1B2128),
    onSurface = Color(0xFFE8EDF2),
    surfaceVariant = Color(0xFF252D36),
    onSurfaceVariant = Color(0xFFB7C0CA),
    error = Color(0xFFFF8A80),
)

@Composable
fun LiederratenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}

@Composable
fun App(
    vm: GameViewModel,
    onLogin: () -> Unit,
    onOpenSpotify: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    val state by vm.state.collectAsState()
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            when (state.screen) {
                Screen.Login -> LoginScreen(state, onLogin)
                Screen.Playlists -> PlaylistScreen(
                    state = state,
                    onSelect = vm::selectPlaylist,
                    onReload = vm::loadPlaylists,
                    onLogout = vm::logout,
                )
                Screen.Game -> GameScreen(
                    state = state,
                    onReveal = vm::reveal,
                    onNext = vm::next,
                    onTogglePause = vm::togglePause,
                    onBack = vm::backToPlaylists,
                    onRestart = vm::restart,
                    onOpenSpotify = onOpenSpotify,
                    onOpenTrack = onOpenTrack,
                )
            }
            if (state.loading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun SpotifyAttribution() {
    Text(
        text = "Musik und Metadaten: Spotify",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ErrorText(message: String?) {
    if (message != null) {
        Spacer(Modifier.height(16.dp))
        Text(
            text = message,
            color = MaterialTheme.colorScheme.error,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun LoginScreen(state: UiState, onLogin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Liederraten", fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Errate den Song. Interpret, Titel und Jahr siehst du erst, wenn du tippst.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onLogin, enabled = !state.loading) {
            Text("Mit Spotify verbinden")
        }
        ErrorText(state.error)
        Spacer(Modifier.height(32.dp))
        SpotifyAttribution()
    }
}

@Composable
private fun PlaylistScreen(
    state: UiState,
    onSelect: (Playlist) -> Unit,
    onReload: () -> Unit,
    onLogout: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = state.playlists.filter { it.name.contains(query.trim(), ignoreCase = true) }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Playlist wählen",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onLogout) { Text("Abmelden") }
        }

        if (state.error != null) {
            ErrorText(state.error)
            TextButton(onClick = onReload) { Text("Erneut laden") }
        }
        Spacer(Modifier.height(12.dp))

        if (state.playlists.size > 5) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Playlist suchen") },
                singleLine = true,
                trailingIcon = {
                    if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("✕") }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
        }

        if (query.isNotBlank() && shown.isEmpty()) {
            Text("Keine Playlist gefunden.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (state.playlistsLoaded && state.playlists.isEmpty() && !state.loading) {
            Text(
                text = "Keine eigenen Playlists gefunden.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(shown, key = { it.id }) { playlist ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(playlist) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(playlist.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        if (playlist.trackCount != null) {
                            Text(
                                text = "${playlist.trackCount} Songs",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        Text(
            text = "Angezeigt werden nur eigene und gemeinsam bearbeitete Playlists (Spotify-Einschränkung).",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
        )
        SpotifyAttribution()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GameScreen(
    state: UiState,
    onReveal: () -> Unit,
    onNext: () -> Unit,
    onTogglePause: () -> Unit,
    onBack: () -> Unit,
    onRestart: () -> Unit,
    onOpenSpotify: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    BackHandler(onBack = onBack)
    val error = state.error

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Playlists") }
            Spacer(Modifier.weight(1f))
            if (!state.finished) {
                Text(
                    text = "Song ${state.position} / ${state.total}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            if (state.starting) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(20.dp))
                    Text(
                        text = "Der erste Song wird geladen …",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else if (state.finished) {
                FinishedCard(onRestart = onRestart, onBack = onBack)
            } else {
                SongCard(
                    song = state.current,
                    revealed = state.revealed,
                    onReveal = onReveal,
                    onOpenTrack = onOpenTrack,
                )
            }
        }

        if (error != null) {
            ErrorText(error)
            TextButton(onClick = onOpenSpotify) { Text("Spotify öffnen") }
        }
        Spacer(Modifier.height(12.dp))

        if (!state.finished) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedButton(onClick = onTogglePause, modifier = Modifier.height(56.dp)) {
                    Text(if (state.playing) "Pause" else "Abspielen")
                }
                Button(onClick = onNext, enabled = !state.starting, modifier = Modifier.weight(1f).height(56.dp)) {
                    Text("Weiter", fontSize = 18.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        SpotifyAttribution()
    }
}

@Composable
private fun SongCard(
    song: Song?,
    revealed: Boolean,
    onReveal: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 320.dp)
            .clickable(enabled = !revealed) { onReveal() },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Crossfade(targetState = revealed, label = "reveal") { shown ->
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (!shown || song == null) {
                    Text(
                        text = "?",
                        fontSize = 120.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = "Tippe, um die Lösung zu sehen",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        text = song.title,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = song.artists,
                        fontSize = 20.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (song.year.isNotEmpty()) {
                        Spacer(Modifier.height(20.dp))
                        Text(
                            text = song.year,
                            fontSize = 48.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { onOpenTrack(song.uri) }) { Text("In Spotify öffnen") }
                }
            }
        }
    }
}

@Composable
private fun FinishedCard(onRestart: () -> Unit, onBack: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Alle Songs durch!", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onRestart) { Text("Nochmal mischen") }
            TextButton(onClick = onBack) { Text("Andere Playlist") }
        }
    }
}
