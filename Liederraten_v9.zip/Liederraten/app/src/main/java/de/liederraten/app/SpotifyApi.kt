package de.liederraten.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: String, val name: String, val trackCount: Int?)

data class Song(val uri: String, val title: String, val artists: String, val year: String)

class SpotifyApi(private val auth: SpotifyAuth) {

    private companion object {
        const val BASE = "https://api.spotify.com/v1"
        const val MAX_RETRIES = 3
        const val MAX_WAIT_SECONDS = 30L
    }

    /**
     * Ruft die API auf. Bei 429 wird mit Retry-After (sonst exponentiell: 1, 2, 4 s)
     * gewartet und höchstens dreimal wiederholt.
     */
    private suspend fun call(method: String, path: String, body: String? = null): Http.Response {
        var attempt = 0
        while (true) {
            val r = callOnce(method, path, body)
            if (r.code != 429 || attempt >= MAX_RETRIES) return r
            val waitSeconds = r.retryAfterSeconds?.toLong() ?: (1L shl attempt)
            if (waitSeconds > MAX_WAIT_SECONDS) return r
            delay(waitSeconds * 1000)
            attempt++
        }
    }

    private suspend fun callOnce(method: String, path: String, body: String? = null): Http.Response =
        withContext(Dispatchers.IO) {
            val url = if (path.startsWith("http")) path else BASE + path
            var token = auth.validAccessToken() ?: throw ApiException(401, "Nicht angemeldet.")
            var r = Http.request(method, url, token, body)
            if (r.code == 401 && auth.refresh()) {
                token = auth.validAccessToken() ?: throw ApiException(401, "Nicht angemeldet.")
                r = Http.request(method, url, token, body)
            }
            r
        }

    private fun ensureOk(r: Http.Response) {
        if (r.code !in 200..299) throw ApiException(r.code, Http.errorMessage(r))
    }

    private fun nextUrl(json: JSONObject): String? =
        if (json.isNull("next")) null else json.optString("next").ifEmpty { null }

    private suspend fun myId(): String {
        val r = call("GET", "/me")
        ensureOk(r)
        return JSONObject(r.body).getString("id")
    }

    /** Eigene und gemeinsam bearbeitete Playlists (nur dort liefert Spotify die Songs). */
    suspend fun myPlaylists(): List<Playlist> {
        val me = myId()
        val result = mutableListOf<Playlist>()
        var next: String? = "/me/playlists?limit=50"
        while (next != null) {
            val r = call("GET", next)
            ensureOk(r)
            val json = JSONObject(r.body)
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val p = items.optJSONObject(i) ?: continue
                val ownerId = p.optJSONObject("owner")?.optString("id")
                val usable = ownerId == me || p.optBoolean("collaborative", false)
                if (!usable) continue
                val counts = p.optJSONObject("items") ?: p.optJSONObject("tracks")
                val total = counts?.optInt("total", -1) ?: -1
                result.add(
                    Playlist(
                        id = p.getString("id"),
                        name = p.optString("name", "Ohne Namen"),
                        trackCount = if (total >= 0) total else null,
                    ),
                )
            }
            next = nextUrl(json)
        }
        return result
    }

    /** Alle abspielbaren Songs einer Playlist. */
    suspend fun playlistSongs(playlistId: String): List<Song> {
        val songs = mutableListOf<Song>()
        var next: String? = "/playlists/$playlistId/items?limit=100"
        while (next != null) {
            val r = call("GET", next)
            if (r.code == 403 || r.code == 404) {
                throw ApiException(
                    r.code,
                    "Diese Playlist kann nicht gelesen werden. Spotify erlaubt Entwickler-Apps " +
                        "nur Zugriff auf eigene oder gemeinsam bearbeitete Playlists.",
                )
            }
            ensureOk(r)
            val json = JSONObject(r.body)
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val entry = items.optJSONObject(i) ?: continue
                if (entry.optBoolean("is_local", false)) continue
                // Neues Feld heißt "item", das alte "track" – beides akzeptieren.
                val t = entry.optJSONObject("item") ?: entry.optJSONObject("track") ?: continue
                if (t.optString("type", "track") != "track") continue
                if (t.optBoolean("is_local", false)) continue
                val uri = t.optString("uri")
                if (uri.isEmpty()) continue
                val artistArray = t.optJSONArray("artists")
                val artists = if (artistArray == null) "" else {
                    (0 until artistArray.length())
                        .mapNotNull { artistArray.optJSONObject(it)?.optString("name") }
                        .joinToString(", ")
                }
                val year = t.optJSONObject("album")?.optString("release_date", "")?.take(4) ?: ""
                songs.add(Song(uri, t.optString("name"), artists, year))
            }
            next = nextUrl(json)
        }
        return songs
    }

    private suspend fun firstDeviceId(): String? {
        val r = call("GET", "/me/player/devices")
        ensureOk(r)
        val devices = JSONObject(r.body).optJSONArray("devices") ?: return null
        var fallback: String? = null
        for (i in 0 until devices.length()) {
            val d = devices.optJSONObject(i) ?: continue
            if (d.optBoolean("is_restricted", false) || d.isNull("id")) continue
            val id = d.optString("id")
            if (id.isEmpty()) continue
            if (d.optBoolean("is_active", false)) return id
            if (fallback == null) fallback = id
        }
        return fallback
    }

    private var deviceId: String? = null

    /** Vergisst das gemerkte Gerät (z.B. bei neuer Playlist). */
    fun forgetDevice() {
        deviceId = null
    }

    private fun playPath(id: String?): String =
        if (id == null) "/me/player/play" else "/me/player/play?device_id=$id"

    private data class PlayerStatus(
        val isPlaying: Boolean,
        val deviceId: String?,
        val deviceName: String?,
        val details: String,
        val itemUri: String? = null,
    )

    private fun JSONObject.stringOrNull(name: String): String? =
        if (isNull(name)) null else optString(name).ifEmpty { null }

    /** Aktueller Wiedergabestatus (GET /me/player). 204 = kein aktives Gerät. */
    private suspend fun playerStatus(): PlayerStatus {
        val r = call("GET", "/me/player")
        if (r.code == 204 || r.body.isBlank()) {
            return PlayerStatus(false, null, null, "Spotify meldet kein aktives Gerät (Antwort ${r.code})")
        }
        ensureOk(r)
        val json = JSONObject(r.body)
        val device = json.optJSONObject("device")
        val item = json.optJSONObject("item")
        val disallows = json.optJSONObject("actions")?.optJSONObject("disallows")
        val blocked = if (disallows == null) "" else {
            disallows.keys().asSequence().filter { disallows.optBoolean(it) }.joinToString(",")
        }
        val details = "Gerät ${device?.stringOrNull("name")} " +
            "(Typ ${device?.stringOrNull("type")}, aktiv ${device?.optBoolean("is_active")}, " +
            "eingeschränkt ${device?.optBoolean("is_restricted")}, " +
            "privat ${device?.optBoolean("is_private_session")}), " +
            "geladen ${item?.stringOrNull("uri") ?: "nichts"}, gesperrt [$blocked]"
        return PlayerStatus(
            isPlaying = json.optBoolean("is_playing", false),
            deviceId = device?.stringOrNull("id"),
            deviceName = device?.stringOrNull("name"),
            details = details,
            itemUri = item?.stringOrNull("uri"),
        )
    }

    /** Fragt mehrmals kurz nach, ob Spotify wirklich spielt. */
    private suspend fun waitUntilPlaying(delayMs: Long, polls: Int, expectedUri: String? = null): PlayerStatus {
        var status = PlayerStatus(false, null, null, "")
        repeat(polls) {
            delay(delayMs)
            status = playerStatus()
            if (status.isPlaying && (expectedUri == null || status.itemUri == expectedUri)) return status
        }
        return status.copy(isPlaying = false)
    }

    /** Legt einen Song in Spotifys Warteschlange (wird dort schon vorgeladen). */
    suspend fun enqueue(uri: String): Boolean {
        val device = deviceId?.let { "&device_id=$it" } ?: ""
        val r = call("POST", "/me/player/queue?uri=" + java.net.URLEncoder.encode(uri, "UTF-8") + device)
        return r.code in 200..299
    }

    /** Springt zum vorgeladenen Song. Gibt false zurück, wenn nicht genau dieser Song läuft. */
    suspend fun playQueued(expectedUri: String): Boolean {
        val device = deviceId?.let { "?device_id=$it" } ?: ""
        val r = call("POST", "/me/player/next$device")
        if (r.code !in 200..299) return false
        val status = waitUntilPlaying(500, 3, expectedUri)
        return status.isPlaying
    }

    /**
     * Spielt einen Song ab. Schnelle Kontrolle (0,7 s), dann Wiederholung gezielt auf dem Gerät,
     * zuletzt über die Playlist als Kontext. Wirft eine ApiException mit Erklärung, falls nichts klappt.
     */
    suspend fun play(uri: String, playlistId: String?) {
        val uriBody = JSONObject().put("uris", JSONArray().put(uri)).toString()
        var id = deviceId ?: firstDeviceId()
        var r = call("PUT", playPath(id), uriBody)
        if (r.code == 404) {
            id = firstDeviceId() ?: throw ApiException(404, Http.NO_DEVICE_MESSAGE)
            r = call("PUT", playPath(id), uriBody)
        }
        ensureOk(r)
        deviceId = id
        val firstCode = r.code

        // Kurze Kontrolle. Meldet Spotify noch nichts, derselbe Befehl noch einmal.
        // Kein Fehler, wenn die Statusmeldung nur hinterherhinkt: der Befehl selbst war erfolgreich.
        val status = waitUntilPlaying(700, 1, uri)
        if (!status.isPlaying && status.itemUri != uri) {
            val again = status.deviceId ?: id
            ensureOk(call("PUT", playPath(again), uriBody))
        }
    }

    suspend fun pause() {
        val r = call("PUT", "/me/player/pause")
        // 403/404: schon pausiert bzw. kein Gerät – für uns egal.
        if (r.code != 403 && r.code != 404) ensureOk(r)
    }

    suspend fun resume() {
        val r = call("PUT", "/me/player/play")
        // 403 "Restriction violated": läuft schon – für uns egal.
        if (r.code != 403) ensureOk(r)
    }
}
