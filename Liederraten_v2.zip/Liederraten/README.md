# Liederraten

Android-App (Kotlin + Jetpack Compose): Playlist aus Spotify wählen, Song läuft ohne Anzeige,
Tippen in die Mitte zeigt Titel, Interpret und Jahr, „Weiter“ spielt den nächsten Song.
Die Wiedergabe läuft über die Spotify-App auf deinem Handy (oder einem anderen Spotify-Gerät). Premium ist nötig.

## 1. Spotify-Dashboard (einmalig)

Die Client ID steht schon in `gradle.properties`. Im Dashboard unter *Edit* bei **Redirect URIs**
diese URI hinzufügen und speichern:

    http://127.0.0.1:8888/callback

(Die alte `liederraten://callback` kann weg. Die App nutzt sie nicht mehr.)
„Web API“ muss bei „APIs used“ angekreuzt sein.
Falls der Login „User not registered“ meldet: unter *User Management* deine Spotify-E-Mail eintragen.

## 2. APK bauen

**Mit GitHub (ohne Android Studio):**
1. Neues (privates) Repository auf github.com anlegen.
2. Den **Inhalt** des Ordners hochladen (*Add file > Upload files*), inkl. dem Ordner `.github`.
3. Reiter *Actions > APK bauen > Run workflow*. Nach ein paar Minuten steht unter dem Lauf bei
   *Artifacts* die Datei `liederraten-apk` (ZIP mit `app-debug.apk`).

**Mit Android Studio:** Ordner öffnen, Gradle-Sync abwarten, *Build > Build APK(s)*.
Die Datei liegt unter `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Installieren

APK aufs Handy kopieren und öffnen (Installation aus unbekannten Quellen erlauben).

## So hält sich die App an Spotifys Regeln

- Login: Authorization Code mit PKCE, Redirect nur auf `http://127.0.0.1:8888/callback`
  (lokaler Mini-Server in der App, hört nur auf dem Loopback-Interface). Kein Client Secret in der App.
- Scopes: `playlist-read-private`, `playlist-read-collaborative`, `user-modify-playback-state`,
  `user-read-playback-state` (Letzteres nur, um ein Gerät zu finden, wenn keins aktiv ist).
- Tokens liegen AES-256-GCM-verschlüsselt (Android Keystore). Läuft der Refresh-Token ab, geht es zurück zum Login.
- Endpunkte: `/me/playlists`, `/playlists/{id}/items` (nicht das veraltete `/tracks`), `/me/player/play|pause|devices`.
- Bei HTTP 429 wartet die App (Retry-After, sonst 1/2/4 s) und versucht es höchstens dreimal erneut.
- Songdaten bleiben nur im Arbeitsspeicher und werden nicht gespeichert. Die App zeigt „Musik und Metadaten: Spotify“
  und verlinkt per „In Spotify öffnen“ zurück zu Spotify.

## Hinweise

- Spotify erlaubt Entwickler-Apps nur Zugriff auf **eigene oder gemeinsam bearbeitete Playlists**.
  Fremde Playlists vorher in eine eigene Playlist kopieren. „Lieblingssongs“ ist keine normale Playlist.
- Das Jahr stammt vom Album. Bei Samplern oder Remasters kann es später sein als das Originaljahr.
- Läuft ein Song, zeigt die Spotify-App (Benachrichtigungsleiste, Sperrbildschirm) den Titel an.
  Am besten über ein anderes Gerät abspielen (Spotify Connect) oder die Leiste nicht aufziehen.
- Beim Login öffnet sich ein Browserfenster. Danach „Zurück zu Liederraten“ tippen oder das Fenster schließen.
