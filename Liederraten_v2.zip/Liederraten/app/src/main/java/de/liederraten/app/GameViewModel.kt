package de.liederraten.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.UnknownHostException

enum class Screen { Login, Playlists, Game }

data class UiState(
    val screen: Screen = Screen.Login,
    val loading: Boolean = false,
    val error: String? = null,
    val playlists: List<Playlist> = emptyList(),
    val playlistsLoaded: Boolean = false,
    val current: Song? = null,
    val revealed: Boolean = false,
    val playing: Boolean = false,
    val position: Int = 0,
    val total: Int = 0,
    val finished: Boolean = false,
)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val store = TokenStore(app)
    private val auth = SpotifyAuth(store)
    private val api = SpotifyApi(auth)

    private val _state = MutableStateFlow(
        UiState(screen = if (auth.isLoggedIn) Screen.Playlists else Screen.Login),
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var allSongs: List<Song> = emptyList()
    private val queue = ArrayDeque<Song>()

    private var loginServer: LoopbackServer? = null
    private var loginJob: Job? = null

    init {
        if (auth.isLoggedIn) loadPlaylists()
    }

    // ---------- Login ----------

    fun startLogin(): Uri? {
        if (!SpotifyConfig.isConfigured) {
            _state.update { s ->
                s.copy(error = "Die Spotify Client-ID fehlt. Trage sie in gradle.properties ein und baue die App neu.")
            }
            return null
        }
        loginJob?.cancel()
        loginServer?.close()
        val server = try {
            LoopbackServer.open()
        } catch (e: IOException) {
            _state.update { s ->
                s.copy(error = "Der lokale Port ${SpotifyConfig.LOOPBACK_PORT} ist belegt. Bitte die App neu starten.")
            }
            return null
        }
        loginServer = server
        _state.update { s -> s.copy(error = null) }
        val uri = auth.buildAuthUri()
        loginJob = viewModelScope.launch {
            val redirect = server.awaitRedirect()
            if (redirect != null) completeLogin(redirect)
        }
        return uri
    }

    private suspend fun completeLogin(uri: Uri) {
        _state.update { s -> s.copy(loading = true, error = null) }
        auth.handleRedirect(uri)
            .onSuccess {
                _state.update { s -> s.copy(screen = Screen.Playlists, loading = false) }
                loadPlaylists()
            }
            .onFailure { e -> fail(e) }
    }

    override fun onCleared() {
        loginServer?.close()
        super.onCleared()
    }

    fun logout() {
        auth.logout()
        queue.clear()
        _state.value = UiState(screen = Screen.Login)
    }

    // ---------- Playlists ----------

    fun loadPlaylists() {
        viewModelScope.launch {
            _state.update { s -> s.copy(loading = true, error = null) }
            try {
                val list = api.myPlaylists()
                _state.update { s -> s.copy(playlists = list, playlistsLoaded = true, loading = false) }
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun selectPlaylist(playlist: Playlist) {
        viewModelScope.launch {
            _state.update { s -> s.copy(loading = true, error = null) }
            try {
                val songs = api.playlistSongs(playlist.id)
                if (songs.isEmpty()) {
                    _state.update { s ->
                        s.copy(loading = false, error = "Diese Playlist enthält keine abspielbaren Songs.")
                    }
                    return@launch
                }
                allSongs = songs
                startRound()
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    // ---------- Spiel ----------

    private fun startRound() {
        queue.clear()
        queue.addAll(allSongs.shuffled())
        _state.update { s ->
            s.copy(
                screen = Screen.Game,
                loading = false,
                error = null,
                total = allSongs.size,
                position = 0,
                finished = false,
                current = null,
                revealed = false,
            )
        }
        next()
    }

    fun restart() = startRound()

    fun reveal() {
        _state.update { s -> s.copy(revealed = true) }
    }

    fun next() {
        val song = queue.removeFirstOrNull()
        if (song == null) {
            _state.update { s -> s.copy(current = null, finished = true, playing = false, revealed = false) }
            viewModelScope.launch { runCatching { api.pause() } }
            return
        }
        _state.update { s ->
            s.copy(
                current = song,
                revealed = false,
                playing = true,
                error = null,
                finished = false,
                position = s.total - queue.size,
            )
        }
        viewModelScope.launch {
            try {
                api.play(song.uri)
            } catch (e: Exception) {
                _state.update { s -> s.copy(playing = false) }
                fail(e)
            }
        }
    }

    fun togglePause() {
        val wasPlaying = _state.value.playing
        _state.update { s -> s.copy(playing = !wasPlaying) }
        viewModelScope.launch {
            try {
                if (wasPlaying) api.pause() else api.resume()
            } catch (e: Exception) {
                _state.update { s -> s.copy(playing = wasPlaying) }
                fail(e)
            }
        }
    }

    fun backToPlaylists() {
        queue.clear()
        _state.update { s ->
            s.copy(
                screen = Screen.Playlists,
                current = null,
                revealed = false,
                playing = false,
                finished = false,
                error = null,
            )
        }
        viewModelScope.launch { runCatching { api.pause() } }
    }

    // ---------- Fehler ----------

    private fun fail(e: Throwable) {
        if (e is ApiException && e.code == 401) {
            auth.logout()
            _state.value = UiState(screen = Screen.Login, error = "Bitte melde dich neu bei Spotify an.")
            return
        }
        val text = when (e) {
            is UnknownHostException -> "Keine Internetverbindung."
            else -> e.message ?: "Unbekannter Fehler."
        }
        _state.update { s -> s.copy(loading = false, error = text) }
    }
}
