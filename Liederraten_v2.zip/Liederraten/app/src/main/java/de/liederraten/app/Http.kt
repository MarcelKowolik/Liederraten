package de.liederraten.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(val code: Int, message: String) : IOException(message)

object Http {
    data class Response(val code: Int, val body: String, val retryAfterSeconds: Int? = null)

    const val NO_DEVICE_MESSAGE =
        "Kein Spotify-Gerät gefunden. Öffne die Spotify-App, starte kurz einen Song " +
            "und tippe dann erneut auf Weiter."

    /** Blockierender HTTP-Aufruf. Immer auf Dispatchers.IO ausführen. */
    fun request(
        method: String,
        url: String,
        bearer: String? = null,
        body: String? = null,
        contentType: String? = null,
    ): Response {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            if (bearer != null) conn.setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                conn.setRequestProperty("Content-Type", contentType ?: "application/json")
            }
            if (method == "PUT" || method == "POST") {
                conn.doOutput = true
                conn.outputStream.use { out ->
                    if (body != null) out.write(body.toByteArray(Charsets.UTF_8))
                }
            }
            val code = conn.responseCode
            val retryAfter = conn.getHeaderField("Retry-After")?.trim()?.toIntOrNull()
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Response(code, text, retryAfter)
        } finally {
            conn.disconnect()
        }
    }

    fun postForm(url: String, params: Map<String, String>): JSONObject {
        val body = params.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        val r = request("POST", url, body = body, contentType = "application/x-www-form-urlencoded")
        if (r.code !in 200..299) throw ApiException(r.code, errorMessage(r))
        return JSONObject(r.body)
    }

    /** Liest die Fehlermeldung aus der Antwort von Spotify und macht daraus einen lesbaren Text. */
    fun errorMessage(r: Response): String {
        if (r.code == 429) {
            return "Zu viele Anfragen an Spotify. Bitte kurz warten und erneut versuchen."
        }
        val apiMessage: String? = try {
            val json = JSONObject(r.body)
            when (val err = json.opt("error")) {
                is JSONObject -> when (err.optString("reason")) {
                    "PREMIUM_REQUIRED" -> "Dafür ist Spotify Premium nötig."
                    "NO_ACTIVE_DEVICE" -> NO_DEVICE_MESSAGE
                    else -> err.optString("message").ifEmpty { null }
                }
                is String -> json.optString("error_description").ifEmpty { err }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
        if (apiMessage != null) return apiMessage
        return when {
            r.code >= 500 -> "Spotify ist gerade nicht erreichbar (Fehler ${r.code}). Bitte später erneut versuchen."
            else -> "Fehler ${r.code}"
        }
    }
}
