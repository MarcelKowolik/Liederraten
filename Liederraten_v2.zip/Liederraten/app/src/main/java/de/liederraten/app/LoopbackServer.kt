package de.liederraten.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Winziger lokaler Server auf 127.0.0.1, der die Weiterleitung von Spotify
 * (http://127.0.0.1:8888/callback?code=...) entgegennimmt. Hört nur auf dem Loopback-Interface.
 */
class LoopbackServer private constructor(private val socket: ServerSocket) {

    companion object {
        fun open(): LoopbackServer {
            val socket = ServerSocket()
            socket.reuseAddress = true
            socket.bind(
                InetSocketAddress(InetAddress.getByName("127.0.0.1"), SpotifyConfig.LOOPBACK_PORT),
                1,
            )
            return LoopbackServer(socket)
        }

        private const val BACK_LINK =
            "intent:#Intent;action=android.intent.action.MAIN;" +
                "category=android.intent.category.LAUNCHER;package=de.liederraten.app;end"
    }

    /** Wartet (max. 3 Minuten) auf den Aufruf von /callback und liefert die vollständige URL. */
    suspend fun awaitRedirect(): Uri? = withContext(Dispatchers.IO) {
        var result: Uri? = null
        try {
            socket.soTimeout = 180_000
            while (result == null) {
                val client = socket.accept()
                try {
                    client.use { c ->
                        c.soTimeout = 5_000
                        val line = c.getInputStream().bufferedReader(Charsets.US_ASCII).readLine() ?: ""
                        val target = line.split(" ").getOrNull(1) ?: ""
                        val isCallback = target.startsWith("/callback")
                        respond(c, isCallback)
                        if (isCallback) {
                            result = Uri.parse("http://127.0.0.1:${SpotifyConfig.LOOPBACK_PORT}$target")
                        }
                    }
                } catch (e: IOException) {
                    // Leere oder abgebrochene Verbindung (z.B. vom Browser vorab geöffnet): ignorieren
                }
            }
        } catch (e: IOException) {
            // Timeout oder Server wurde geschlossen
        } finally {
            close()
        }
        result
    }

    fun close() {
        try {
            socket.close()
        } catch (e: IOException) {
            // schon zu
        }
    }

    private fun respond(client: Socket, ok: Boolean) {
        val html = if (ok) {
            "<h2>Anmeldung abgeschlossen</h2>" +
                "<p>Du kannst dieses Fenster schließen.</p>" +
                "<p><a href=\"$BACK_LINK\">Zurück zu Liederraten</a></p>"
        } else {
            "<h2>Nicht gefunden</h2>"
        }
        val page = "<html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head>" +
            "<body style=\"font-family:sans-serif;text-align:center;padding:40px\">$html</body></html>"
        val bytes = page.toByteArray(Charsets.UTF_8)
        val status = if (ok) "200 OK" else "404 Not Found"
        val header = "HTTP/1.1 $status\r\nContent-Type: text/html; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
        val out = client.getOutputStream()
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }
}
