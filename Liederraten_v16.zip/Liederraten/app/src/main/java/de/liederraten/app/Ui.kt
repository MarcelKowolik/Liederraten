package de.liederraten.app

import androidx.activity.compose.BackHandler
import android.content.res.Configuration
import android.graphics.BitmapFactory
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF04210F),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE8EDF2),
    surface = Color(0xFF1B2128),
    onSurface = Color(0xFFE8EDF2),
    surfaceVariant = Color(0xFF252D36),
    onSurfaceVariant = Color(0xFFB7C0CA),
    error = Color(0xFFFF8A80),
)

@Composable
fun LiederratenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}

private val BlackScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF04210F),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE8EDF2),
    surface = Color(0xFF0E1114),
    onSurface = Color(0xFFE8EDF2),
    surfaceVariant = Color(0xFF1A1F26),
    onSurfaceVariant = Color(0xFFB7C0CA),
    error = Color(0xFFFF8A80),
)

@Composable
fun App(
    vm: GameViewModel,
    onLogin: () -> Unit,
    onOpenSpotify: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    val state by vm.state.collectAsState()
    MaterialTheme(colorScheme = if (state.oled) BlackScheme else DarkScheme) {
        AppContent(vm, onLogin, onOpenSpotify, onOpenTrack)
    }
}

@Composable
private fun AppContent(
    vm: GameViewModel,
    onLogin: () -> Unit,
    onOpenSpotify: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    val state by vm.state.collectAsState()
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            when (state.screen) {
                Screen.Login -> LoginScreen(state, onLogin)
                Screen.Playlists -> PlaylistScreen(
                    state = state,
                    onSelect = vm::selectPlaylist,
                    onReload = vm::loadPlaylists,
                    onLogout = vm::logout,
                    onSettings = vm::openSettings,
                    onResume = vm::resumeSession,
                    onToggleSelect = vm::toggleSelect,
                    onStartSelected = vm::startSelected,
                )
                Screen.Game -> GameScreen(
                    state = state,
                    onReveal = vm::reveal,
                    onNext = vm::next,
                    onTogglePause = vm::togglePause,
                    onBack = vm::backToPlaylists,
                    onRestart = vm::restart,
                    onSettings = vm::openSettings,
                    onHistory = vm::openHistory,
                    onFavorite = vm::favorite,
                    onOpenSpotify = onOpenSpotify,
                    onOpenTrack = onOpenTrack,
                )
            }
            if (state.loading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
            if (state.showHistory) HistoryDialog(state.history, vm::closeHistory)
            if (state.showDevices) DevicesDialog(state, vm::chooseDevice, vm::closeDevices)
            if (state.showSettings) {
                SettingsDialog(
                    state = state,
                    onRandomStart = vm::setRandomStart,
                    onShowCover = vm::setShowCover,
                    onOled = vm::setOled,
                    onAutoSpotify = vm::setAutoSpotify,
                    onDevices = vm::openDevices,
                    onClose = vm::closeSettings,
                )
            }
        }
    }
}

@Composable
private fun SpotifyAttribution() {
    Text(
        text = "Musik und Metadaten: Spotify",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ErrorText(message: String?) {
    if (message != null) {
        Spacer(Modifier.height(16.dp))
        Text(
            text = message,
            color = MaterialTheme.colorScheme.error,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun LoginScreen(state: UiState, onLogin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Liederraten", fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Errate den Song. Interpret, Titel und Jahr siehst du erst, wenn du tippst.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onLogin, enabled = !state.loading) {
            Text("Mit Spotify verbinden")
        }
        ErrorText(state.error)
        Spacer(Modifier.height(32.dp))
        SpotifyAttribution()
    }
}

@Composable
private fun PlaylistScreen(
    state: UiState,
    onSelect: (Playlist) -> Unit,
    onReload: () -> Unit,
    onLogout: () -> Unit,
    onSettings: () -> Unit,
    onResume: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onStartSelected: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = state.playlists.filter { it.name.contains(query.trim(), ignoreCase = true) }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Playlist wählen",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onLogout) { Text("Abmelden") }
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 24.sp) }
        }

        if (state.error != null) {
            ErrorText(state.error)
            TextButton(onClick = onReload) { Text("Erneut laden") }
        }
        Spacer(Modifier.height(12.dp))

        if (state.resumeName != null) {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onResume() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Weiterspielen", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "${state.resumeName} · noch ${state.resumeLeft} Songs",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (state.playlists.size > 5) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Playlist suchen") },
                singleLine = true,
                trailingIcon = {
                    if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("✕") }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
        }

        if (query.isNotBlank() && shown.isEmpty()) {
            Text("Keine Playlist gefunden.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (state.playlistsLoaded && state.playlists.isEmpty() && !state.loading) {
            Text(
                text = "Keine eigenen Playlists gefunden.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(shown, key = { it.id }) { playlist ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(playlist) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Row(
                        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playlist.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            if (playlist.trackCount != null) {
                                Text(
                                    text = "${playlist.trackCount} Songs",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Checkbox(
                            checked = playlist.id in state.selected,
                            onCheckedChange = { onToggleSelect(playlist.id) },
                        )
                    }
                }
            }
        }

        if (state.selected.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Button(onClick = onStartSelected, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("${state.selected.size} Playlists mischen und starten")
            }
        }
        Text(
            text = "Haken setzen = mehrere Playlists zu einer Runde mischen. Angezeigt werden nur eigene und gemeinsam bearbeitete Playlists (Spotify-Einschränkung).",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
        )
        SpotifyAttribution()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GameScreen(
    state: UiState,
    onReveal: () -> Unit,
    onNext: () -> Unit,
    onTogglePause: () -> Unit,
    onBack: () -> Unit,
    onRestart: () -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
    onFavorite: (Song) -> Unit,
    onOpenSpotify: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    BackHandler(onBack = onBack)
    val error = state.error
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(state.starting, state.finished) {
                // Nach links wischen = Weiter.
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragCancel = { total = 0f },
                    onDragEnd = {
                        if (total < -150f && !state.starting && !state.finished) onNext()
                        total = 0f
                    },
                ) { _, dx -> total += dx }
            }
            .padding(horizontal = 20.dp, vertical = if (landscape) 4.dp else 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Playlists") }
            Spacer(Modifier.weight(1f))
            if (!state.finished) {
                Text(
                    text = "Song ${state.position} / ${state.total}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onHistory) { Text("≡", fontSize = 24.sp) }
            TextButton(onClick = onSettings) { Text("⚙", fontSize = 24.sp) }
        }

        val card: @Composable () -> Unit = {
            if (state.starting) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(20.dp))
                    Text(
                        text = "Der erste Song wird geladen …",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else if (state.finished) {
                FinishedCard(onRestart = onRestart, onBack = onBack)
            } else {
                SongCard(
                    song = state.current,
                    revealed = state.revealed,
                    seen = state.seen,
                    showCover = state.showCover,
                    compact = landscape,
                    favorited = state.current?.uri in state.favorites,
                    onReveal = onReveal,
                    onFavorite = { state.current?.let(onFavorite) },
                    onOpenTrack = onOpenTrack,
                )
            }
        }

        if (landscape) {
            Row(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier.weight(1.3f).fillMaxHeight(),
                    contentAlignment = Alignment.Center,
                ) { card() }
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    if (error != null) {
                        ErrorText(error)
                        TextButton(onClick = onOpenSpotify) { Text("Spotify öffnen") }
                        Spacer(Modifier.height(8.dp))
                    }
                    if (!state.finished) {
                        Button(
                            onClick = onNext,
                            enabled = !state.starting,
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                        ) { Text("Weiter", fontSize = 18.sp) }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = onTogglePause,
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) { Text(if (state.playing) "Pause" else "Abspielen") }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) { card() }

            if (error != null) {
                ErrorText(error)
                TextButton(onClick = onOpenSpotify) { Text("Spotify öffnen") }
            }
            Spacer(Modifier.height(12.dp))

            if (!state.finished) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedButton(onClick = onTogglePause, modifier = Modifier.height(56.dp)) {
                        Text(if (state.playing) "Pause" else "Abspielen")
                    }
                    Button(
                        onClick = onNext,
                        enabled = !state.starting,
                        modifier = Modifier.weight(1f).height(56.dp),
                    ) { Text("Weiter", fontSize = 18.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        SpotifyAttribution()
    }
}

@Composable
private fun SongCard(
    song: Song?,
    revealed: Boolean,
    seen: Boolean,
    showCover: Boolean,
    compact: Boolean,
    favorited: Boolean,
    onReveal: () -> Unit,
    onFavorite: () -> Unit,
    onOpenTrack: (String) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val minHeight = if (compact) 0.dp else 320.dp
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = minHeight)
            .clickable {
                if (!revealed) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onReveal()
            },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        // Pro Song neu aufbauen, damit beim Wechsel nicht der nächste Song kurz aufblitzt.
        key(song?.uri) {
        Crossfade(targetState = revealed, label = "reveal") { shown ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = minHeight)
                    .then(if (compact) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                    .padding(if (compact) 12.dp else 24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (!shown || song == null) {
                    Text(
                        text = if (seen) "!" else "?",
                        fontSize = if (compact) 72.sp else 120.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = if (seen) "Tippe, um die Lösung wieder zu sehen" else "Tippe, um die Lösung zu sehen",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    if (showCover) CoverImage(song.cover, if (compact) 80.dp else 150.dp)
                    Text(
                        text = song.title,
                        fontSize = if (compact) 22.sp else 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = song.artists,
                        fontSize = if (compact) 16.sp else 20.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (song.year.isNotEmpty()) {
                        Spacer(Modifier.height(if (compact) 8.dp else 20.dp))
                        Text(
                            text = song.year,
                            fontSize = if (compact) 36.sp else 48.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(Modifier.height(if (compact) 4.dp else 12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { onOpenTrack(song.uri) }) { Text("In Spotify öffnen") }
                        TextButton(onClick = onFavorite, enabled = !favorited) {
                            Text(if (favorited) "♥ Gemerkt" else "♡ Favorit")
                        }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun HistoryDialog(songs: List<Song>, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Bisher gespielt") },
        text = {
            if (songs.isEmpty()) {
                Text("In dieser Runde noch nichts gespielt.")
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 400.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(songs) { s ->
                        Column {
                            Text(s.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = listOf(s.artists, s.year).filter { it.isNotEmpty() }.joinToString(" · "),
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Schließen") } },
    )
}

@Composable
private fun DevicesDialog(state: UiState, onPick: (Device) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Wiedergabegerät") },
        text = {
            when {
                state.devicesLoading -> CircularProgressIndicator()
                state.devices.isEmpty() -> Text("Kein Gerät gefunden. Öffne Spotify auf dem Gerät und versuche es noch einmal.")
                else -> Column {
                    state.devices.forEach { d ->
                        TextButton(onClick = { onPick(d) }) {
                            Text((if (d.active) "● " else "") + d.name + " (" + d.type + ")")
                        }
                    }
                    Text(
                        text = "Ein laufender Song startet auf dem neuen Gerät von vorn.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Abbrechen") } },
    )
}

@Composable
private fun FinishedCard(onRestart: () -> Unit, onBack: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Alle Songs durch!", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onRestart) { Text("Nochmal mischen") }
            TextButton(onClick = onBack) { Text("Andere Playlist") }
        }
    }
}

/** Albumcover von Spotify. Wird nur direkt angezeigt und nicht gespeichert. */
@Composable
private fun CoverImage(url: String, size: androidx.compose.ui.unit.Dp) {
    if (url.isEmpty()) return
    var bitmap by remember(url) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                URL(url).openStream().use { BitmapFactory.decodeStream(it) }?.asImageBitmap()
            }.getOrNull()
        }
    }
    val img = bitmap
    if (img != null) {
        Image(
            bitmap = img,
            contentDescription = "Albumcover",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(16.dp)),
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SettingRow(title: String, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsDialog(
    state: UiState,
    onRandomStart: (Boolean) -> Unit,
    onShowCover: (Boolean) -> Unit,
    onOled: (Boolean) -> Unit,
    onAutoSpotify: (Boolean) -> Unit,
    onDevices: () -> Unit,
    onClose: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Einstellungen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                SettingRow(
                    "Zufälliger Startpunkt",
                    "Der Song startet in der Mitte statt am Anfang. Gilt ab dem nächsten Song.",
                    state.randomStart,
                    onRandomStart,
                )
                SettingRow("Albumcover anzeigen", "Nach dem Aufdecken.", state.showCover, onShowCover)
                SettingRow("Echtes Schwarz (OLED)", "Tiefschwarzer Hintergrund.", state.oled, onOled)
                SettingRow(
                    "Spotify beim Öffnen starten",
                    "Öffnet beim App-Start kurz Spotify, damit ein Gerät bereit ist.",
                    state.autoSpotify,
                    onAutoSpotify,
                )
                TextButton(onClick = onDevices) { Text("Wiedergabegerät wählen ›") }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fertig") } },
    )
}
