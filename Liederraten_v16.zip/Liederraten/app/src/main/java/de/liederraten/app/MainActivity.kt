package de.liederraten.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.app.ActivityManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.WindowManager

class MainActivity : ComponentActivity() {

    private val vm: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        hideSystemBars()
        if (savedInstanceState == null && Settings(application).autoSpotify) startSpotifyAndReturn()
        setContent {
            LiederratenTheme {
                App(
                    vm = vm,
                    onLogin = ::openLogin,
                    onOpenSpotify = ::openSpotify,
                    onOpenTrack = ::openTrack,
                )
            }
        }
    }

    /** Vollbild: Statusleiste und Navigationsleiste ausblenden (Wischen vom Rand zeigt sie kurz). */
    private fun hideSystemBars() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Startet beim App-Start Spotify und holt Liederraten kurz darauf wieder nach vorn. */
    private fun startSpotifyAndReturn() {
        val launch = packageManager.getLaunchIntentForPackage("com.spotify.music") ?: return
        try {
            startActivity(launch)
        } catch (e: Exception) {
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                getSystemService(ActivityManager::class.java).moveTaskToFront(taskId, 0)
            } catch (e: Exception) {
                // Android erlaubt das nicht immer: dann bleibt Spotify vorn.
            }
        }, 2500)
    }

    private fun openLogin() {
        val uri = vm.startLogin() ?: return
        CustomTabsIntent.Builder().build().launchUrl(this, uri)
    }

    private fun openSpotify() {
        val launch = packageManager.getLaunchIntentForPackage("com.spotify.music")
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Spotify-App nicht gefunden.", Toast.LENGTH_SHORT).show()
        }
    }

    /** Öffnet den Song in der Spotify-App (Verlinkung zurück zu Spotify). */
    private fun openTrack(uri: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Spotify-App nicht gefunden.", Toast.LENGTH_SHORT).show()
        }
    }
}
