package de.liederraten.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.UnknownHostException

enum class Screen { Login, Playlists, Game }

data class UiState(
    val screen: Screen = Screen.Login,
    val loading: Boolean = false,
    val error: String? = null,
    val playlists: List<Playlist> = emptyList(),
    val playlistsLoaded: Boolean = false,
    val current: Song? = null,
    val revealed: Boolean = false,
    val playing: Boolean = false,
    val position: Int = 0,
    val total: Int = 0,
    val finished: Boolean = false,
    val starting: Boolean = false,
    val seen: Boolean = false,
    val randomStart: Boolean = false,
    val showCover: Boolean = true,
    val showSettings: Boolean = false,
    val oled: Boolean = true,
    val autoSpotify: Boolean = true,
    val resumeName: String? = null,
    val resumeLeft: Int = 0,
    val selected: Set<String> = emptySet(),
    val history: List<Song> = emptyList(),
    val showHistory: Boolean = false,
    val favorites: Set<String> = emptySet(),
    val showDevices: Boolean = false,
    val devicesLoading: Boolean = false,
    val devices: List<Device> = emptyList(),
)

/** Einstellungen (nur lokale Schalter, keine Spotify-Daten). */
class Settings(app: Application) {
    private val sp = app.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
    var randomStart: Boolean
        get() = sp.getBoolean("randomStart", false)
        set(v) = sp.edit().putBoolean("randomStart", v).apply()
    var showCover: Boolean
        get() = sp.getBoolean("showCover", true)
        set(v) = sp.edit().putBoolean("showCover", v).apply()
    var oled: Boolean
        get() = sp.getBoolean("oled", true)
        set(v) = sp.edit().putBoolean("oled", v).apply()
    var autoSpotify: Boolean
        get() = sp.getBoolean("autoSpotify", true)
        set(v) = sp.edit().putBoolean("autoSpotify", v).apply()

    // Gespeicherte Runde: nur Playlist-ID und die Reihenfolge der Song-IDs, keine Spotify-Inhalte.
    var sessionId: String?
        get() = sp.getString("sessionId", null)
        set(v) = sp.edit().putString("sessionId", v).apply()
    var sessionName: String?
        get() = sp.getString("sessionName", null)
        set(v) = sp.edit().putString("sessionName", v).apply()
    var sessionRemaining: String
        get() = sp.getString("sessionRemaining", "") ?: ""
        set(v) = sp.edit().putString("sessionRemaining", v).apply()
    var favId: String?
        get() = sp.getString("favId", null)
        set(v) = sp.edit().putString("favId", v).apply()
    var sessionLeft: Int
        get() = sp.getInt("sessionLeft", 0)
        set(v) = sp.edit().putInt("sessionLeft", v).apply()

    fun clearSession() {
        sp.edit().remove("sessionId").remove("sessionName").remove("sessionRemaining").remove("sessionLeft").apply()
    }
}

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private companion object {
        /** Vorladen über Spotifys Warteschlange (erst nach bestätigtem Start des Songs). */
        const val USE_QUEUE = true
    }

    private val store = TokenStore(app)
    private val auth = SpotifyAuth(store)
    private val api = SpotifyApi(auth)
    private val settings = Settings(app)

    private fun baseState(screen: Screen, error: String? = null) = UiState(
        screen = screen,
        error = error,
        randomStart = settings.randomStart,
        showCover = settings.showCover,
        oled = settings.oled,
        autoSpotify = settings.autoSpotify,
        resumeName = if (settings.sessionId != null) settings.sessionName else null,
        resumeLeft = if (settings.sessionId != null) settings.sessionLeft else 0,
    )

    private val _state = MutableStateFlow(
        baseState(if (auth.isLoggedIn) Screen.Playlists else Screen.Login),
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var allSongs: List<Song> = emptyList()
    private var playlistId: String? = null
    private val queue = ArrayDeque<Song>()

    private var loginServer: LoopbackServer? = null
    private var loginJob: Job? = null
    private var playJob: Job? = null
    private var queuedUri: String? = null
    private var playlistName: String = ""
    private var playlistIds: List<String> = emptyList()
    private var pollJob: Job? = null
    private var lastPlayEnd = 0L
    private var mismatchUri: String? = null

    init {
        if (auth.isLoggedIn) loadPlaylists()
    }

    // ---------- Login ----------

    fun startLogin(): Uri? {
        if (!SpotifyConfig.isConfigured) {
            _state.update { s ->
                s.copy(error = "Die Spotify Client-ID fehlt. Trage sie in gradle.properties ein und baue die App neu.")
            }
            return null
        }
        loginJob?.cancel()
        loginServer?.close()
        val server = try {
            LoopbackServer.open()
        } catch (e: IOException) {
            _state.update { s ->
                s.copy(error = "Der lokale Port ${SpotifyConfig.LOOPBACK_PORT} ist belegt. Bitte die App neu starten.")
            }
            return null
        }
        loginServer = server
        _state.update { s -> s.copy(error = null) }
        val uri = auth.buildAuthUri()
        loginJob = viewModelScope.launch {
            val redirect = server.awaitRedirect()
            if (redirect != null) completeLogin(redirect)
        }
        return uri
    }

    private suspend fun completeLogin(uri: Uri) {
        _state.update { s -> s.copy(loading = true, error = null) }
        auth.handleRedirect(uri)
            .onSuccess {
                _state.update { s -> s.copy(screen = Screen.Playlists, loading = false) }
                loadPlaylists()
            }
            .onFailure { e -> fail(e) }
    }

    override fun onCleared() {
        pollJob?.cancel()
        loginServer?.close()
        super.onCleared()
    }

    fun logout() {
        auth.logout()
        queue.clear()
        settings.clearSession()
        _state.value = baseState(Screen.Login)
    }

    // ---------- Playlists ----------

    fun loadPlaylists() {
        viewModelScope.launch {
            _state.update { s -> s.copy(loading = true, error = null) }
            try {
                val list = api.myPlaylists()
                _state.update { s -> s.copy(playlists = list, playlistsLoaded = true, loading = false) }
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun selectPlaylist(playlist: Playlist) = startPlaylists(listOf(playlist))

    fun toggleSelect(id: String) = _state.update {
        it.copy(selected = if (id in it.selected) it.selected - id else it.selected + id)
    }

    fun startSelected() {
        val chosen = _state.value.playlists.filter { it.id in _state.value.selected }
        if (chosen.isNotEmpty()) startPlaylists(chosen)
    }

    private fun startPlaylists(list: List<Playlist>) {
        viewModelScope.launch {
            _state.update { s -> s.copy(loading = true, error = null) }
            try {
                val songs = list.flatMap { api.playlistSongs(it.id) }.distinctBy { it.uri }
                if (songs.isEmpty()) {
                    _state.update { s ->
                        s.copy(loading = false, error = "Diese Playlist enthält keine abspielbaren Songs.")
                    }
                    return@launch
                }
                allSongs = songs
                playlistIds = list.map { it.id }
                playlistId = list.singleOrNull()?.id
                playlistName = list.joinToString(" + ") { it.name }
                api.forgetDevice()
                _state.update { s -> s.copy(selected = emptySet()) }
                startRound()
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    // ---------- Spiel ----------

    private fun startRound(order: List<Song>? = null) {
        startSync()
        queuedUri = null
        queue.clear()
        queue.addAll(order ?: allSongs.shuffled())
        _state.update { s ->
            s.copy(
                screen = Screen.Game,
                loading = false,
                error = null,
                total = allSongs.size,
                position = 0,
                finished = false,
                current = null,
                revealed = false,
                seen = false,
                starting = true,
                history = emptyList(),
            )
        }
        next()
    }

    fun restart() = startRound()

    private fun saveSession() {
        if (playlistIds.isEmpty()) return
        val rest = listOfNotNull(_state.value.current) + queue
        settings.sessionId = playlistIds.joinToString(",")
        settings.sessionName = playlistName
        settings.sessionRemaining = rest.joinToString(",") { it.uri }
        settings.sessionLeft = rest.size
        _state.update { it.copy(resumeName = playlistName, resumeLeft = rest.size) }
    }

    private fun clearSession() {
        settings.clearSession()
        _state.update { it.copy(resumeName = null, resumeLeft = 0) }
    }

    /** Setzt die zuletzt gespielte Runde mit gleicher Reihenfolge fort. */
    fun resumeSession() {
        val ids = (settings.sessionId ?: return).split(",").filter { it.isNotEmpty() }
        val saved = settings.sessionRemaining.split(",").filter { it.isNotEmpty() }
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val songs = ids.flatMap { api.playlistSongs(it) }.distinctBy { it.uri }
                val byUri = songs.associateBy { it.uri }
                val rest = saved.mapNotNull { byUri[it] }
                if (rest.isEmpty()) {
                    clearSession()
                    _state.update { it.copy(loading = false, error = "Die gespeicherte Runde ist leer.") }
                    return@launch
                }
                allSongs = songs
                playlistIds = ids
                playlistId = ids.singleOrNull()
                playlistName = settings.sessionName ?: ""
                api.forgetDevice()
                startRound(rest)
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun setOled(v: Boolean) {
        settings.oled = v
        _state.update { it.copy(oled = v) }
    }
    fun setAutoSpotify(v: Boolean) {
        settings.autoSpotify = v
        _state.update { it.copy(autoSpotify = v) }
    }

    fun openHistory() = _state.update { it.copy(showHistory = true) }
    fun closeHistory() = _state.update { it.copy(showHistory = false) }

    /** Merkt den Song in der privaten Playlist "Liederraten Favoriten". */
    fun favorite(song: Song) {
        if (song.uri in _state.value.favorites) return
        viewModelScope.launch {
            try {
                settings.favId = api.addToFavorites(settings.favId, song.uri)
                _state.update { it.copy(favorites = it.favorites + song.uri) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun openDevices() {
        _state.update { it.copy(showSettings = false, showDevices = true, devicesLoading = true) }
        viewModelScope.launch {
            try {
                val list = api.devices()
                _state.update { it.copy(devices = list, devicesLoading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(showDevices = false, devicesLoading = false) }
                fail(e)
            }
        }
    }

    fun closeDevices() = _state.update { it.copy(showDevices = false) }

    /** Wählt das Wiedergabegerät. Läuft gerade ein Song, startet er dort von vorn. */
    fun chooseDevice(device: Device) {
        api.chooseDevice(device.id)
        _state.update { it.copy(showDevices = false) }
        val cur = _state.value.current
        if (cur != null && _state.value.screen == Screen.Game && !_state.value.finished) {
            playJob?.cancel()
            playJob = viewModelScope.launch {
                try {
                    api.play(cur.uri, playlistId, 0)
                    _state.update { it.copy(playing = true) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    fail(e)
                } finally {
                    lastPlayEnd = System.currentTimeMillis()
                }
            }
        }
    }

    fun openSettings() = _state.update { it.copy(showSettings = true) }
    fun closeSettings() = _state.update { it.copy(showSettings = false) }
    fun setRandomStart(v: Boolean) {
        settings.randomStart = v
        queuedUri = null
        _state.update { it.copy(randomStart = v) }
    }
    fun setShowCover(v: Boolean) {
        settings.showCover = v
        _state.update { it.copy(showCover = v) }
    }

    fun reveal() {
        _state.update { s -> s.copy(revealed = !s.revealed, seen = s.seen || !s.revealed) }
    }

    fun next() {
        val song = queue.removeFirstOrNull()
        if (song == null) {
            clearSession()
            _state.update { s ->
                s.copy(
                    current = null,
                    finished = true,
                    playing = false,
                    revealed = false,
                    history = listOfNotNull(s.current) + s.history,
                )
            }
            viewModelScope.launch { runCatching { api.pause() } }
            return
        }
        _state.update { s ->
            s.copy(
                current = song,
                revealed = false,
                seen = false,
                playing = true,
                error = null,
                finished = false,
                position = s.total - queue.size,
                history = listOfNotNull(s.current) + s.history,
            )
        }
        saveSession()
        // Einen noch laufenden Abspielversuch des vorigen Songs abbrechen.
        playJob?.cancel()
        playJob = viewModelScope.launch {
            try {
                val useQueue = USE_QUEUE && !settings.randomStart
                val viaQueue = useQueue && song.uri == queuedUri && api.playQueued(song.uri)
                queuedUri = null
                if (!viaQueue) api.play(song.uri, playlistId, startPosition(song))
                // Den nächsten Song schon in Spotifys Warteschlange legen, damit er vorgeladen ist.
                val upcoming = queue.firstOrNull()
                _state.update { s -> s.copy(starting = false) }
                if (useQueue && upcoming != null && api.enqueue(upcoming.uri)) queuedUri = upcoming.uri
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { s -> s.copy(playing = false, starting = false) }
                fail(e)
            } finally {
                lastPlayEnd = System.currentTimeMillis()
            }
        }
    }

    // ---------- Abgleich mit Spotify ----------

    private fun startSync() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                try {
                    syncOnce()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Abgleich ist nur ein Zusatz: Fehler hier ignorieren.
                }
            }
        }
    }

    /** Folgt Spotify: Wechselt dort der Song (z.B. in der Spotify-App), zieht die App nach. */
    private suspend fun syncOnce() {
        val s = _state.value
        val cur = s.current ?: return
        if (s.screen != Screen.Game || s.finished || s.starting) return
        if (playJob?.isActive == true || System.currentTimeMillis() - lastPlayEnd < 4000) return
        val now = api.nowPlaying() ?: return
        val uri = now.itemUri ?: return
        if (uri == cur.uri) {
            mismatchUri = null
            if (now.isPlaying != s.playing) _state.update { it.copy(playing = now.isPlaying) }
            return
        }
        val song = allSongs.firstOrNull { it.uri == uri } ?: return
        // Erst bei zwei Abfragen hintereinander umschalten, damit eine hinterherhinkende Meldung nicht stört.
        if (mismatchUri != uri) {
            mismatchUri = uri
            return
        }
        mismatchUri = null
        queue.removeAll { it.uri == song.uri }
        queuedUri = null
        _state.update {
            it.copy(
                current = song,
                revealed = false,
                seen = false,
                playing = now.isPlaying,
                position = it.total - queue.size,
                history = listOf(cur) + it.history,
                error = null,
            )
        }
        saveSession()
    }

    /** Zufälliger Startpunkt (25 bis 65 Prozent), nur wenn in den Einstellungen an. */
    private fun startPosition(song: Song): Int {
        if (!settings.randomStart || song.durationMs < 60_000) return 0
        return kotlin.random.Random.nextInt((song.durationMs * 0.25).toInt(), (song.durationMs * 0.65).toInt())
    }

    fun togglePause() {
        val wasPlaying = _state.value.playing
        _state.update { s -> s.copy(playing = !wasPlaying) }
        viewModelScope.launch {
            try {
                if (wasPlaying) api.pause() else api.resume()
            } catch (e: Exception) {
                _state.update { s -> s.copy(playing = wasPlaying) }
                fail(e)
            }
        }
    }

    fun backToPlaylists() {
        playJob?.cancel()
        pollJob?.cancel()
        queuedUri = null
        queue.clear()
        _state.update { s ->
            s.copy(
                screen = Screen.Playlists,
                current = null,
                revealed = false,
                seen = false,
                playing = false,
                finished = false,
                starting = false,
                error = null,
            )
        }
        viewModelScope.launch { runCatching { api.pause() } }
    }

    // ---------- Fehler ----------

    private fun fail(e: Throwable) {
        if (e is ApiException && e.code == 401) {
            auth.logout()
            _state.value = baseState(Screen.Login, "Bitte melde dich neu bei Spotify an.")
            return
        }
        val text = when (e) {
            is UnknownHostException -> "Keine Internetverbindung."
            else -> e.message ?: "Unbekannter Fehler."
        }
        _state.update { s -> s.copy(loading = false, error = text) }
    }
}
