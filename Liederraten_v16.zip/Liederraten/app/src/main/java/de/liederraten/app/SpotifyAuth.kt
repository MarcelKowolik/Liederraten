package de.liederraten.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom

object SpotifyConfig {
    const val LOOPBACK_PORT = 8888

    // Muss exakt so im Spotify Developer Dashboard eingetragen sein.
    const val REDIRECT_URI = "http://127.0.0.1:$LOOPBACK_PORT/callback"

    // Nur das Nötigste: Playlists lesen (eigene + gemeinsame), Wiedergabe steuern, Geräte sehen,
    // und die private Favoriten-Playlist anlegen/befüllen.
    const val SCOPES =
        "playlist-read-private playlist-read-collaborative " +
            "user-modify-playback-state user-read-playback-state " +
            "playlist-modify-private"
    const val AUTH_URL = "https://accounts.spotify.com/authorize"
    const val TOKEN_URL = "https://accounts.spotify.com/api/token"

    val clientId: String get() = BuildConfig.SPOTIFY_CLIENT_ID
    val isConfigured: Boolean
        get() = clientId.isNotBlank() && !clientId.startsWith("HIER_")
}

/** Tokens und PKCE-Daten, verschlüsselt im Android Keystore abgesichert. */
class TokenStore(context: Context) {
    private val secure = SecureStore(context, "spotify_auth_v2")

    var accessToken: String?
        get() = secure.get("access_token")
        set(value) = secure.put("access_token", value)

    var refreshToken: String?
        get() = secure.get("refresh_token")
        set(value) = secure.put("refresh_token", value)

    var expiresAt: Long
        get() = secure.get("expires_at")?.toLongOrNull() ?: 0L
        set(value) = secure.put("expires_at", value.toString())

    var verifier: String?
        get() = secure.get("pkce_verifier")
        set(value) = secure.put("pkce_verifier", value)

    var state: String?
        get() = secure.get("pkce_state")
        set(value) = secure.put("pkce_state", value)

    fun clear() = secure.clear()
}

object Pkce {
    private const val CHARS =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"

    fun randomString(length: Int): String {
        val random = SecureRandom()
        return buildString {
            repeat(length) { append(CHARS[random.nextInt(CHARS.length)]) }
        }
    }

    fun challenge(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(
            digest,
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
        )
    }
}

class SpotifyAuth(private val store: TokenStore) {

    val isLoggedIn: Boolean get() = store.refreshToken != null

    /** Baut die Login-URL (Authorization Code mit PKCE) und merkt sich Verifier + State. */
    fun buildAuthUri(): Uri {
        val verifier = Pkce.randomString(96)
        val state = Pkce.randomString(16)
        store.verifier = verifier
        store.state = state
        return Uri.parse(SpotifyConfig.AUTH_URL).buildUpon()
            .appendQueryParameter("client_id", SpotifyConfig.clientId)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", SpotifyConfig.REDIRECT_URI)
            .appendQueryParameter("scope", SpotifyConfig.SCOPES)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("code_challenge", Pkce.challenge(verifier))
            .appendQueryParameter("state", state)
            .build()
    }

    /** Wird mit der Rückkehr-URL (http://127.0.0.1:8888/callback?code=...) aufgerufen. */
    suspend fun handleRedirect(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val error = uri.getQueryParameter("error")
            if (error != null) throw IOException("Anmeldung abgebrochen ($error).")
            val code = uri.getQueryParameter("code")
                ?: throw IOException("Spotify hat keinen Code geliefert.")
            if (uri.getQueryParameter("state") != store.state) {
                throw IOException("Ungültige Antwort von Spotify (state). Bitte erneut versuchen.")
            }
            val verifier = store.verifier
                ?: throw IOException("Login-Daten fehlen. Bitte erneut versuchen.")
            val json = Http.postForm(
                SpotifyConfig.TOKEN_URL,
                mapOf(
                    "grant_type" to "authorization_code",
                    "code" to code,
                    "redirect_uri" to SpotifyConfig.REDIRECT_URI,
                    "client_id" to SpotifyConfig.clientId,
                    "code_verifier" to verifier,
                ),
            )
            saveTokens(json)
            store.verifier = null
            store.state = null
        }
    }

    /** Holt mit dem Refresh-Token einen neuen Access-Token. */
    suspend fun refresh(): Boolean = withContext(Dispatchers.IO) {
        val refresh = store.refreshToken ?: return@withContext false
        try {
            val json = Http.postForm(
                SpotifyConfig.TOKEN_URL,
                mapOf(
                    "grant_type" to "refresh_token",
                    "refresh_token" to refresh,
                    "client_id" to SpotifyConfig.clientId,
                ),
            )
            saveTokens(json)
            true
        } catch (e: IOException) {
            // 400 invalid_grant: Refresh-Token abgelaufen oder widerrufen -> neu anmelden
            if (e is ApiException && e.code == 400) store.clear()
            false
        }
    }

    suspend fun validAccessToken(): String? {
        val token = store.accessToken
        if (token != null && System.currentTimeMillis() < store.expiresAt - 60_000) return token
        return if (refresh()) store.accessToken else null
    }

    fun logout() = store.clear()

    private fun saveTokens(json: JSONObject) {
        store.accessToken = json.getString("access_token")
        store.expiresAt = System.currentTimeMillis() + json.optLong("expires_in", 3600) * 1000
        val refresh = json.optString("refresh_token")
        if (refresh.isNotEmpty()) store.refreshToken = refresh
    }
}
