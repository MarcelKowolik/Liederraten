package de.liederraten.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: String, val name: String, val trackCount: Int?)

data class Song(val uri: String, val title: String, val artists: String, val year: String)

class SpotifyApi(private val auth: SpotifyAuth) {

    private companion object {
        const val BASE = "https://api.spotify.com/v1"
        const val MAX_RETRIES = 3
        const val MAX_WAIT_SECONDS = 30L
    }

    /**
     * Ruft die API auf. Bei 429 wird mit Retry-After (sonst exponentiell: 1, 2, 4 s)
     * gewartet und höchstens dreimal wiederholt.
     */
    private suspend fun call(method: String, path: String, body: String? = null): Http.Response {
        var attempt = 0
        while (true) {
            val r = callOnce(method, path, body)
            if (r.code != 429 || attempt >= MAX_RETRIES) return r
            val waitSeconds = r.retryAfterSeconds?.toLong() ?: (1L shl attempt)
            if (waitSeconds > MAX_WAIT_SECONDS) return r
            delay(waitSeconds * 1000)
            attempt++
        }
    }

    private suspend fun callOnce(method: String, path: String, body: String? = null): Http.Response =
        withContext(Dispatchers.IO) {
            val url = if (path.startsWith("http")) path else BASE + path
            var token = auth.validAccessToken() ?: throw ApiException(401, "Nicht angemeldet.")
            var r = Http.request(method, url, token, body)
            if (r.code == 401 && auth.refresh()) {
                token = auth.validAccessToken() ?: throw ApiException(401, "Nicht angemeldet.")
                r = Http.request(method, url, token, body)
            }
            r
        }

    private fun ensureOk(r: Http.Response) {
        if (r.code !in 200..299) throw ApiException(r.code, Http.errorMessage(r))
    }

    private fun nextUrl(json: JSONObject): String? =
        if (json.isNull("next")) null else json.optString("next").ifEmpty { null }

    private suspend fun myId(): String {
        val r = call("GET", "/me")
        ensureOk(r)
        return JSONObject(r.body).getString("id")
    }

    /** Eigene und gemeinsam bearbeitete Playlists (nur dort liefert Spotify die Songs). */
    suspend fun myPlaylists(): List<Playlist> {
        val me = myId()
        val result = mutableListOf<Playlist>()
        var next: String? = "/me/playlists?limit=50"
        while (next != null) {
            val r = call("GET", next)
            ensureOk(r)
            val json = JSONObject(r.body)
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val p = items.optJSONObject(i) ?: continue
                val ownerId = p.optJSONObject("owner")?.optString("id")
                val usable = ownerId == me || p.optBoolean("collaborative", false)
                if (!usable) continue
                val counts = p.optJSONObject("items") ?: p.optJSONObject("tracks")
                val total = counts?.optInt("total", -1) ?: -1
                result.add(
                    Playlist(
                        id = p.getString("id"),
                        name = p.optString("name", "Ohne Namen"),
                        trackCount = if (total >= 0) total else null,
                    ),
                )
            }
            next = nextUrl(json)
        }
        return result
    }

    /** Alle abspielbaren Songs einer Playlist. */
    suspend fun playlistSongs(playlistId: String): List<Song> {
        val songs = mutableListOf<Song>()
        var next: String? = "/playlists/$playlistId/items?limit=100"
        while (next != null) {
            val r = call("GET", next)
            if (r.code == 403 || r.code == 404) {
                throw ApiException(
                    r.code,
                    "Diese Playlist kann nicht gelesen werden. Spotify erlaubt Entwickler-Apps " +
                        "nur Zugriff auf eigene oder gemeinsam bearbeitete Playlists.",
                )
            }
            ensureOk(r)
            val json = JSONObject(r.body)
            val items = json.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val entry = items.optJSONObject(i) ?: continue
                if (entry.optBoolean("is_local", false)) continue
                // Neues Feld heißt "item", das alte "track" – beides akzeptieren.
                val t = entry.optJSONObject("item") ?: entry.optJSONObject("track") ?: continue
                if (t.optString("type", "track") != "track") continue
                if (t.optBoolean("is_local", false)) continue
                val uri = t.optString("uri")
                if (uri.isEmpty()) continue
                val artistArray = t.optJSONArray("artists")
                val artists = if (artistArray == null) "" else {
                    (0 until artistArray.length())
                        .mapNotNull { artistArray.optJSONObject(it)?.optString("name") }
                        .joinToString(", ")
                }
                val year = t.optJSONObject("album")?.optString("release_date", "")?.take(4) ?: ""
                songs.add(Song(uri, t.optString("name"), artists, year))
            }
            next = nextUrl(json)
        }
        return songs
    }

    private suspend fun firstDeviceId(): String? {
        val r = call("GET", "/me/player/devices")
        ensureOk(r)
        val devices = JSONObject(r.body).optJSONArray("devices") ?: return null
        var fallback: String? = null
        for (i in 0 until devices.length()) {
            val d = devices.optJSONObject(i) ?: continue
            if (d.optBoolean("is_restricted", false) || d.isNull("id")) continue
            val id = d.optString("id")
            if (id.isEmpty()) continue
            if (d.optBoolean("is_active", false)) return id
            if (fallback == null) fallback = id
        }
        return fallback
    }

    /** Spielt einen Song auf dem aktiven Spotify-Gerät ab. */
    suspend fun play(uri: String) {
        val body = JSONObject().put("uris", JSONArray().put(uri)).toString()
        var r = call("PUT", "/me/player/play", body)
        if (r.code == 404) {
            // Kein aktives Gerät: erstes verfügbares Gerät nehmen und aktivieren.
            val deviceId = firstDeviceId() ?: throw ApiException(404, Http.NO_DEVICE_MESSAGE)
            r = call("PUT", "/me/player/play?device_id=$deviceId", body)
        }
        ensureOk(r)
    }

    suspend fun pause() {
        val r = call("PUT", "/me/player/pause")
        // 403/404: schon pausiert bzw. kein Gerät – für uns egal.
        if (r.code != 403 && r.code != 404) ensureOk(r)
    }

    suspend fun resume() {
        ensureOk(call("PUT", "/me/player/play"))
    }
}
